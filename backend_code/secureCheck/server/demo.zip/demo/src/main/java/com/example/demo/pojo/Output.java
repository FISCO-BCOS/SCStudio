package com.example.demo.pojo;


public class Output {
    private String contractname;
    private Vulnerability[] vulnerabilities;


    public String getContractname() {
        return contractname;
    }

    public void setContractname(String contractname) {
        this.contractname = contractname;
    }

    public Vulnerability[] getVulnerabilities() {
        return vulnerabilities;
    }

    public void setVulnerabilities(Vulnerability[] vulnerabilities) {
        this.vulnerabilities = vulnerabilities;
    }
}
