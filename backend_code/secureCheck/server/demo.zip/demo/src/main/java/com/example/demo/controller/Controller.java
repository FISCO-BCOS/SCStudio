package com.example.demo.controller;

import com.example.demo.pojo.Input;
import com.example.demo.pojo.Output;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.springframework.web.bind.annotation.*;

import java.io.*;

@RestController
@RequestMapping("/")
public class Controller {

    @GetMapping("contract")
    public Output get() {
        Output output = new Output();
        output.setContractname("Testingoutput");
        return output;
    }

    @PostMapping("contract")
    public Output post(@RequestBody Input input) throws IOException {
        System.out.println("start reading and examining");
        //extract name and mkdir and name.sol
        String name = input.getName();
        String code = input.getContractcode();

        String rootDir = "/Users/louyang/smartIDE/contract/";
        String contractDirName = rootDir + name;
        String contractname = contractDirName + "/" + name + ".sol";
        File contractDir = new File(contractDirName);
        File contract = new File(contractname);
        if(contractDir.mkdirs()){
            System.out.println("Directory created! Path is："+contractDir.getPath()+"/n Parent directory path："+contractDir.getParent());
        }else {
            if(!contractDir.exists()){
                System.out.println("Fail to create directory!");
            }
        }
        try {
            //创建文件
            contract.createNewFile();
            System.out.println("Create contract file successfully");
            FileWriter fileWritter = new FileWriter(contract,false);
            fileWritter.write(code);
            fileWritter.close();
        } catch (IOException e) {
            System.out.println("Error when loading contract");
        }

        //execute python code


        try {
            String[] arguments = new String[] { "python3", "/Users/louyang/smartIDE/enTool.py", contractDirName};
            Process proc = Runtime.getRuntime().exec(arguments);// 执行py文件

            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            proc.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //read json file finalReport.json from the same directory,map json to Output
        String outputfile = contractDirName + "/finalReport.json";
        ObjectMapper mapper = new ObjectMapper();
        Output output = mapper.readValue(new File(outputfile), Output.class);
        //delete the whole directory
        FileUtils.deleteDirectory(new File(contractDirName));
        //return output
        return output;
    }
}
