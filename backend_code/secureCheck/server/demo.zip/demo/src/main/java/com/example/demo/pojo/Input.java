package com.example.demo.pojo;


public class Input {
    private String name;
    private String contractcode;

    public Input(String name, String contractcode) {
        this.name = name;
        this.contractcode = contractcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContractcode() {
        return contractcode;
    }

    public void setContractcode(String contractcode) {
        this.contractcode = contractcode;
    }
}
